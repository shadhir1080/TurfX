'use client'

import dynamic from 'next/dynamic'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase/client'
import { useAuth } from '@/contexts/AuthContext'
import { Database } from '@/lib/supabase/database.types'
import { STATIC_COIMBATORE_TURFS } from '@/lib/static-turfs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import Navbar from '@/components/layout/Navbar'
import {
  MapPin, Star, Clock, Zap, Moon, BadgeCheck,
  ExternalLink, ChevronLeft, Users, Calendar, ArrowRight
} from 'lucide-react'
import { motion } from 'framer-motion'
import {
  getEffectivePrice, isWeekend, SLOTS, getDirectionsUrl,
  calculateBookingAmount
} from '@/lib/pricing'

// Dynamically import map to avoid SSR issues
const TurfMap = dynamic(() => import('@/components/map/TurfMap'), { ssr: false })

type Turf = Database['public']['Tables']['turfs']['Row']

function generateHourlySlots(timings: string | null | undefined) {
  let startHour = 6
  let endHour = 22

  if (timings) {
    const tLower = timings.toLowerCase()
    if (tLower.includes('24 hours') || tLower.includes('24h')) {
      startHour = 0
      endHour = 24
    } else {
      const parts = timings.split('-')
      if (parts.length === 2) {
        const parseTime = (str: string) => {
          const s = str.trim().toLowerCase()
          let hour = parseInt(s)
          if (s.includes('pm') && hour !== 12) hour += 12
          if (s.includes('am') && hour === 12) hour = 0
          return hour
        }
        try {
          startHour = parseTime(parts[0])
          endHour = parseTime(parts[1])
          if (endHour === 0) endHour = 24
        } catch (e) {
          // fallback
        }
      }
    }
  }

  const slots = []
  for (let h = startHour; h < endHour; h++) {
    const displayHour = h % 12 === 0 ? 12 : h % 12
    const ampm = h >= 12 && h < 24 ? 'PM' : 'AM'
    
    let nextH = h + 1
    const nextDisplayHour = nextH % 12 === 0 ? 12 : nextH % 12
    const nextAmpm = nextH >= 12 && nextH < 24 ? 'PM' : (nextH >= 24 ? 'AM' : 'AM')

    const label = `${displayHour}:00 ${ampm} - ${nextDisplayHour}:00 ${nextAmpm}`
    const id = `${String(h).padStart(2, '0')}:00`
    slots.push({ id, label })
  }
  return slots
}

export default function TurfDetailPage({ params }: { params: { id: string } }) {
  const [turf, setTurf] = useState<Turf | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  )
  const [paymentType, setPaymentType] = useState<'full' | 'advance'>('full')
  const [bookingLoading, setBookingLoading] = useState(false)
  const { user, profile } = useAuth()
  const router = useRouter()

  useEffect(() => {
    fetchTurf()
  }, [params.id])

  const fetchTurf = async () => {
    setLoading(true)
    const UUID_TO_STATIC_ID_MAP: Record<string, string> = {
      '7bed70cf-7696-40df-9fe3-059df533d343': 'static-1',
      '728c4a1f-0954-4818-be5f-b75776d08a26': 'static-2',
      'da460856-6743-4f26-b0dc-0cd5f6870442': 'static-3',
      '06ca7755-ae07-40d2-a21b-f00952bb6950': 'static-4',
      '2f31c0cd-a24f-457b-b8ed-1a3706d2874f': 'static-5',
      'a7c389ad-6f15-41dd-a3a9-841701b853c4': 'static-6',
      'ace2ea04-df99-4887-9b66-8e06d8facddd': 'static-7',
      'ca70eca7-6760-481a-915e-5202d0efcb22': 'static-8',
      '4b3a1298-87d8-4c0d-a48f-fbceeae282c2': 'static-9',
      'ad02d9d1-bee0-4d53-bd37-8d03f0a5b3a8': 'static-10',
    }

    try {
      const { data, error } = await supabase.from('turfs').select('*').eq('id', params.id).single()
      if (error || !data) {
        let staticTurf = STATIC_COIMBATORE_TURFS.find(t => t.id === params.id)
        if (!staticTurf) {
          const mappedId = UUID_TO_STATIC_ID_MAP[params.id]
          if (mappedId) {
            staticTurf = STATIC_COIMBATORE_TURFS.find(t => t.id === mappedId)
          }
        }
        setTurf(staticTurf || STATIC_COIMBATORE_TURFS[0])
      } else {
        setTurf(data)
      }
    } catch {
      let staticTurf = STATIC_COIMBATORE_TURFS.find(t => t.id === params.id)
      if (!staticTurf) {
        const mappedId = UUID_TO_STATIC_ID_MAP[params.id]
        if (mappedId) {
          staticTurf = STATIC_COIMBATORE_TURFS.find(t => t.id === mappedId)
        }
      }
      setTurf(staticTurf || STATIC_COIMBATORE_TURFS[0])
    }
    setLoading(false)
  }

  const location = turf?.location as { city?: string; address?: string; area?: string } | null
  const coordinates = turf?.coordinates as { lat?: number; lng?: number } | null
  const chosenDate = new Date(selectedDate + 'T12:00:00')
  const weekend = isWeekend(chosenDate)
  const effectivePrice = turf ? getEffectivePrice(turf.price_per_hour, chosenDate) : 0

  const commissionRate = turf ? (turf.custom_commission_rate ?? 10) : 10
  const platformFee = Math.round(effectivePrice * (commissionRate / 100))
  const totalAmount = effectivePrice + platformFee

  const advanceAmountVal = Math.round(effectivePrice * 0.3)
  const payNowAmount = paymentType === 'full' ? totalAmount : (advanceAmountVal + platformFee)
  const balanceDue = paymentType === 'full' ? 0 : (totalAmount - payNowAmount)

  const handleBook = async () => {
    if (!user) { router.push('/auth/login'); return }
    if (!selectedSlot || !turf) return
    setBookingLoading(true)

    const startHour = parseInt(selectedSlot.split(':')[0])
    const start = new Date(`${selectedDate}T${String(startHour).padStart(2, '0')}:00:00`)
    const end = new Date(start.getTime() + 60 * 60 * 1000)

    const { data: bookingData, error } = await (supabase.from('bookings') as any).insert({
      user_id: user.id,
      turf_id: turf.id,
      start_time: start.toISOString(),
      end_time: end.toISOString(),
      total_amount: totalAmount,
      commission_amount: platformFee,
      status: 'pending',
      payment_type: paymentType,
      advance_amount: paymentType === 'full' ? totalAmount : advanceAmountVal,
      balance_amount: balanceDue,
    }).select().single()

    if (error || !bookingData) { setBookingLoading(false); return }

    // Redirect to custom razorpay.me link for manual payment collection
    const paymentUrl = `https://razorpay.me/@mohammedshadhir?amount=${payNowAmount}`
    
    if (typeof window !== 'undefined') {
      window.open(paymentUrl, '_blank')
    }
    
    router.push('/dashboard')
    setBookingLoading(false)
  }

  const slots = generateHourlySlots(turf?.timings)

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-24 max-w-5xl mx-auto px-4 space-y-6">
          <div className="shimmer h-80 rounded-2xl" />
          <div className="shimmer h-10 w-1/2 rounded" />
          <div className="shimmer h-6 w-1/3 rounded" />
        </div>
      </div>
    )
  }

  if (!turf) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Navbar />
        <div className="text-center">
          <p className="text-3xl mb-4">🏟️</p>
          <h2 className="text-xl font-bold text-foreground mb-2">Turf not found</h2>
          <Button onClick={() => router.push('/turfs')} className="bg-primary hover:bg-primary/90">Browse Turfs</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      {/* Razorpay script */}
      <script src="https://checkout.razorpay.com/v1/checkout.js" async />

      <div className="pt-20 pb-16 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back */}
        <button onClick={() => router.back()}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6 mt-4 transition-colors">
          <ChevronLeft className="w-4 h-4" /> Back to Turfs
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left — Main Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Hero Image */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="relative h-72 sm:h-80 rounded-2xl overflow-hidden">
              {turf.images && turf.images.length > 0 ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={turf.images[0]} alt={turf.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-primary/20 to-emerald-900/30 flex items-center justify-center">
                  <span className="text-8xl opacity-30">⚽</span>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              {/* Overlay badges */}
              <div className="absolute top-4 left-4 flex gap-2 flex-wrap">
                {turf.is_verified && (
                  <Badge className="bg-primary/90 text-primary-foreground gap-1">
                    <BadgeCheck className="w-3 h-3" /> Verified
                  </Badge>
                )}
                {turf.is_premium && (
                  <Badge className="bg-yellow-500/90 text-black font-bold gap-1">
                    <Zap className="w-3 h-3" /> Premium
                  </Badge>
                )}
                {turf.is_24hours && (
                  <Badge className="bg-blue-600/90 text-white gap-1">
                    <Moon className="w-3 h-3" /> Open All Night
                  </Badge>
                )}
              </div>
            </motion.div>

            {/* Name + Rating */}
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <h1 className="text-3xl font-black text-foreground">{turf.name}</h1>
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <span className="text-xl font-bold text-foreground">{turf.rating ?? '—'}</span>
                  {turf.review_count && (
                    <span className="text-sm text-muted-foreground">({turf.review_count} reviews)</span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1 text-muted-foreground mt-2">
                <MapPin className="w-4 h-4 shrink-0" />
                <span className="text-sm">{location?.address || location?.area}, Coimbatore</span>
                {coordinates?.lat && coordinates?.lng && (
                  <a href={getDirectionsUrl(coordinates.lat, coordinates.lng, turf.name)}
                    target="_blank" rel="noopener noreferrer"
                    className="ml-2 inline-flex items-center gap-1 text-xs text-primary hover:underline font-medium">
                    Get Directions <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>

              <div className="flex items-center gap-1 text-muted-foreground mt-1">
                <Clock className="w-4 h-4 shrink-0" />
                <span className="text-sm">{turf.timings || '—'}</span>
              </div>
            </motion.div>

            {/* Sports */}
            {turf.sports && turf.sports.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Sports Available</h3>
                <div className="flex flex-wrap gap-2">
                  {turf.sports.map(s => (
                    <span key={s} className="px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-sm font-medium">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Description */}
            {turf.description && (
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">About this Turf</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{turf.description}</p>
              </div>
            )}

            {/* Amenities */}
            {turf.amenities && turf.amenities.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Amenities</h3>
                <div className="flex flex-wrap gap-2">
                  {turf.amenities.map(a => (
                    <span key={a} className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-xs text-muted-foreground">
                      {a}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Map */}
            {coordinates?.lat && coordinates?.lng && (
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-primary" /> Location on Map
                </h3>
                <TurfMap
                  turfs={[{ id: turf.id, name: turf.name, lat: coordinates.lat, lng: coordinates.lng, price_per_hour: turf.price_per_hour, rating: turf.rating }]}
                  centerLat={coordinates.lat}
                  centerLng={coordinates.lng}
                  zoom={15}
                  height="320px"
                />
              </div>
            )}
          </div>

          {/* Right — Booking Panel */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card className="glass-dark border-white/10 shadow-2xl">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-bold">Book a Slot</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Pricing */}
                  <div className="bg-primary/10 border border-primary/20 rounded-xl p-4 space-y-1.5">
                    <div className="flex items-baseline gap-2 justify-between">
                      <span className="text-xs text-muted-foreground font-medium">Turf Rate</span>
                      <div className="flex items-baseline gap-1">
                        <span className="text-xl font-black text-foreground">
                          ₹{effectivePrice.toLocaleString('en-IN')}
                        </span>
                        <span className="text-muted-foreground text-xs">/hr</span>
                      </div>
                    </div>

                    <div className="flex items-baseline gap-2 justify-between text-xs border-t border-white/5 pt-1.5 text-muted-foreground">
                      <span>Platform Commission Fee</span>
                      <span>₹{platformFee.toLocaleString('en-IN')}</span>
                    </div>

                    <div className="flex items-baseline gap-2 justify-between text-sm font-bold border-t border-white/10 pt-1.5 text-foreground">
                      <span>Total Amount</span>
                      <span>₹{totalAmount.toLocaleString('en-IN')}</span>
                    </div>

                    {weekend ? (
                      <p className="text-[10px] text-yellow-400 mt-1 font-medium text-center">
                        ⚡ Weekend rate (+20%). Weekday: ₹{turf.price_per_hour.toLocaleString('en-IN')}/hr
                      </p>
                    ) : (
                      <p className="text-[10px] text-muted-foreground mt-1 text-center">
                        Weekend: ₹{Math.round(turf.price_per_hour * 1.2).toLocaleString('en-IN')}/hr
                      </p>
                    )}
                  </div>

                  {/* Date picker */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" /> Select Date
                    </label>
                    <input
                      type="date"
                      value={selectedDate}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={(e) => {
                        setSelectedDate(e.target.value)
                        setSelectedSlot(null) // Reset slot on date change
                      }}
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:border-primary"
                    />
                  </div>

                  {/* Hourly Slot picker */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Select 1-Hour Slot
                    </label>
                    <div className="max-h-48 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                      {slots.length === 0 ? (
                        <p className="text-xs text-muted-foreground py-2">No slots available for this turf.</p>
                      ) : (
                        slots.map((slot) => (
                          <button key={slot.id} onClick={() => setSelectedSlot(slot.id)}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border text-xs transition-all ${
                              selectedSlot === slot.id
                                ? 'border-primary bg-primary/10 text-foreground'
                                : 'border-white/10 bg-white/5 text-muted-foreground hover:border-white/20'
                            }`}>
                            <span className="flex items-center gap-2">
                              <span>⏰</span>
                              <span className="font-medium">{slot.label}</span>
                            </span>
                          </button>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Payment Type Selector */}
                  <div className="space-y-2 border-t border-white/10 pt-3">
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block">
                      Choose Payment Method
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentType('full')}
                        className={`p-2.5 rounded-lg border text-center transition-all ${
                          paymentType === 'full'
                            ? 'border-primary bg-primary/10 text-foreground font-bold'
                            : 'border-white/10 bg-white/5 text-muted-foreground hover:border-white/20 text-xs'
                        }`}
                      >
                        <p className="text-xs">Whole Payment</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">₹{totalAmount}</p>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentType('advance')}
                        className={`p-2.5 rounded-lg border text-center transition-all ${
                          paymentType === 'advance'
                            ? 'border-primary bg-primary/10 text-foreground font-bold'
                            : 'border-white/10 bg-white/5 text-muted-foreground hover:border-white/20 text-xs'
                        }`}
                      >
                        <p className="text-xs">Advance Pay</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">₹{advanceAmountVal + platformFee}</p>
                      </button>
                    </div>
                  </div>

                  {/* Details Breakdown */}
                  <div className="bg-white/5 border border-white/10 rounded-lg p-3 space-y-1 text-xs text-muted-foreground">
                    <div className="flex justify-between">
                      <span>Amount Payable Now:</span>
                      <span className="text-foreground font-semibold">₹{payNowAmount}</span>
                    </div>
                    {paymentType === 'advance' && (
                      <div className="flex justify-between border-t border-white/5 pt-1 mt-1 text-[10px]">
                        <span>Pay remaining balance at Turf:</span>
                        <span className="text-yellow-400 font-semibold">₹{balanceDue}</span>
                      </div>
                    )}
                  </div>

                  {/* Book Button */}
                  <Button
                    onClick={handleBook}
                    disabled={!selectedSlot || bookingLoading}
                    className="w-full h-11 bg-primary hover:bg-primary/90 font-bold text-sm"
                  >
                    {bookingLoading ? 'Processing...' : (
                      <span className="flex items-center gap-2">
                        {paymentType === 'full' ? 'Pay & Book' : 'Pay Advance & Book'} <ArrowRight className="w-4 h-4" />
                      </span>
                    )}
                  </Button>

                  {!user && (
                    <p className="text-center text-[11px] text-muted-foreground">
                      <button onClick={() => router.push('/auth/login')} className="text-primary underline">Sign in</button> to book this turf
                    </p>
                  )}

                  {/* Amenities quick view */}
                  <div className="pt-2 border-t border-white/10">
                    <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                      <Users className="w-3.5 h-3.5" />
                      <span>{turf.review_count?.toLocaleString('en-IN') ?? '—'} players have booked here</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
