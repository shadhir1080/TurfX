import { NextResponse } from 'next/server'
import { supabaseServer } from '@/lib/supabase/server'

const Razorpay = require('razorpay')

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { amount, bookingId, turfId, currency = 'INR' } = body

    const keyId = process.env.RAZORPAY_KEY_ID || ''
    const keySecret = process.env.RAZORPAY_KEY_SECRET || ''
    const isDemoMode = !keyId || keyId === 'your_razorpay_key_id' || !keySecret || keySecret === 'your_razorpay_key_secret'

    if (isDemoMode) {
      const mockOrderId = `mock_order_${Math.random().toString(36).substring(2, 11)}`
      
      // Insert initial payment record in DB
      await (supabaseServer.from('payments') as any).insert({
        booking_id: bookingId,
        razorpay_order_id: mockOrderId,
        status: 'created',
      })

      return NextResponse.json({ orderId: mockOrderId, amount, currency, isDemo: true })
    }

    const razorpay = new Razorpay({
      key_id: keyId,
      key_secret: keySecret,
    })

    const order = await razorpay.orders.create({
      amount: amount * 100, // Razorpay expects paise
      currency,
      receipt: `booking_${bookingId}`,
      notes: {
        booking_id: bookingId,
        turf_id: turfId,
      },
    })

    // Insert initial payment record in DB
    await (supabaseServer.from('payments') as any).insert({
      booking_id: bookingId,
      razorpay_order_id: order.id,
      status: 'created',
    })

    return NextResponse.json({ orderId: order.id, amount, currency, isDemo: false })
  } catch (error: any) {
    console.error('Razorpay order creation error:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
