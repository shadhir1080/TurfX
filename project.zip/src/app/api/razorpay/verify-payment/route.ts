import { NextResponse } from 'next/server'
import crypto from 'crypto'
import { supabaseServer } from '@/lib/supabase/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, bookingId } = body

    const isDemoMode = razorpay_order_id?.startsWith('mock_') || razorpay_signature === 'mock_signature'

    if (!isDemoMode) {
      // Verify signature
      const expectedSignature = crypto
        .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
        .update(`${razorpay_order_id}|${razorpay_payment_id}`)
        .digest('hex')

      if (expectedSignature !== razorpay_signature) {
        return NextResponse.json({ error: 'Invalid payment signature' }, { status: 400 })
      }
    }

    // Update payment record
    await (supabaseServer.from('payments') as any).update({
      razorpay_payment_id,
      status: 'captured',
    }).eq('razorpay_order_id', razorpay_order_id)

    // Update booking status to confirmed
    await (supabaseServer.from('bookings') as any).update({
      status: 'confirmed',
    }).eq('id', bookingId)

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Payment verification error:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
