'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { supabase } from '@/lib/supabase/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Search, UserCheck, UserX, Shield } from 'lucide-react'

export default function AdminUsersPage() {
  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => { fetchUsers() }, [])

  const fetchUsers = async () => {
    setLoading(true)
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false })
    setUsers(data || [])
    setLoading(false)
  }

  const updateRole = async (userId: string, role: string) => {
    await (supabase.from('profiles') as any).update({ role }).eq('id', userId)
    fetchUsers()
  }

  const filtered = users.filter(u =>
    !search || u.full_name?.toLowerCase().includes(search.toLowerCase())
  )

  const roleColors: Record<string, string> = {
    admin: 'bg-red-500/10 text-red-400 border-red-500/20',
    owner: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    user: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-black text-foreground">User Management</h1>
        <p className="text-muted-foreground mt-1">Manage all users, owners, and admins across the platform.</p>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)}
          className="pl-10 bg-white/5 border-white/10" />
      </div>

      <Card className="glass-dark border-white/10">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="w-4 h-4 text-primary" /> All Users ({filtered.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => <div key={i} className="shimmer h-14 rounded-xl" />)}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10">
                    {['Name', 'User ID', 'Role', 'Joined', 'Actions'].map(h => (
                      <th key={h} className="text-left py-3 px-2 text-xs text-muted-foreground font-semibold uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((user, i) => (
                    <motion.tr key={user.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                      className="border-b border-white/5 hover:bg-white/3 transition-colors">
                      <td className="py-3 px-2">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                            {user.full_name?.charAt(0)?.toUpperCase() || '?'}
                          </div>
                          <span className="font-medium text-foreground">{user.full_name || 'Unknown'}</span>
                        </div>
                      </td>
                      <td className="py-3 px-2 text-muted-foreground font-mono text-xs">{user.id.slice(0, 8)}...</td>
                      <td className="py-3 px-2">
                        <Badge variant="outline" className={`text-xs ${roleColors[user.role]}`}>{user.role}</Badge>
                      </td>
                      <td className="py-3 px-2 text-muted-foreground">{new Date(user.created_at).toLocaleDateString('en-IN')}</td>
                      <td className="py-3 px-2">
                        <div className="flex items-center gap-1">
                          {user.role !== 'owner' && (
                            <Button size="sm" variant="ghost" onClick={() => updateRole(user.id, 'owner')}
                              className="text-xs h-7 text-purple-400 hover:text-purple-300 hover:bg-purple-500/10">
                              <UserCheck className="w-3 h-3 mr-1" /> Make Owner
                            </Button>
                          )}
                          {user.role !== 'user' && (
                            <Button size="sm" variant="ghost" onClick={() => updateRole(user.id, 'user')}
                              className="text-xs h-7 text-muted-foreground hover:text-foreground">
                              <UserX className="w-3 h-3 mr-1" /> Set User
                            </Button>
                          )}
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
              {filtered.length === 0 && (
                <div className="text-center py-10 text-muted-foreground">No users found.</div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
